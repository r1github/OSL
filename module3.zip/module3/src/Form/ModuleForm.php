<?php
    /**
     * @file
     * Contains \Drupal\module3\Form\ModuleForm
     */
    namespace Drupal\module3\Form;
    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;
    use Drupal\node\Entity\Node;
    use Drupal\file\Entity\File;

    class ModuleForm extends FormBase{
        /**
         * {@inheritdoc}
         */

         public function getFormId(){
             return 'module_form';
         }

        /**
         * {@inheritdoc}
         */

        public function buildForm(array $form, FormStateInterface $form_state){
            $content = array(
                'Article' => 'article',
                'Basic Page' => 'page'
                
            );
            $form['element'] = [
                '#type' => 'textfield',
                '#attributes' => [
                    ' type' => 'number', // insert space before attribute name
                ],
                '#title' => 'Enter number of Nodes to be generated',
                '#required' => true,
                '#maxlength' => 1
            ];
            $form['type'] = array(
                '#type' => 'select',
                '#title' => t('Content Types'),
                '#options' => $content,
                '#required' => true
            );
            $form['title'] = array(
                '#type' => 'textfield',
                '#title' => t('Title'),
                '#default_value' => '',
                '#required' => true
            );
            $form['body'] = array(
                '#type' => 'textfield',
                '#title' => t('Enter content of body'),
                '#default_value' => '',
                '#required' => true
            );
            $form['save'] = array(
                '#type' => 'submit',
                '#value' => 'Save',
                '#button_type' => 'primary'

            );

            return $form;

        }
        /**
         * {@inheritdoc}
         */
        public function validateForm(array &$form, FormStateInterface $form_state) {
            if($form_state->getValue('element') > 5){
                $form_state->setErrorByName('element', $this->t('Selected number is too long.'));
            }
        }
        public function submitForm(array &$form, FormStateInterface $form_state) {
            for($i=0;$i<$form_state->getValue('element');$i++){
            $node = \Drupal::entityTypeManager()->getStorage('node')->create([
                'type' => $form_state->getValue('type'),
                'title' => $form_state->getValue('title'),
                'body' => array(
                    'value' => $form_state->getValue('body'),
                    'format' => 'basic_html',
                ),
            ]);
            $node ->save();
        }
            return drupal_set_message("New Node is created successfully");
        }
    }