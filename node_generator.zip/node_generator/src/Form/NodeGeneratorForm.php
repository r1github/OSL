<?php
/**
     * @file
     * Contains \Drupal\node_generator\Form\NodeGeneratorForm
     */
    namespace Drupal\node_generator\Form;
    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;
    use Drupal\node\Entity\Node;
    use Drupal\file\Entity\File;

    class NodeGeneratorForm extends FormBase{
        /**
         * {@inheritdoc}
         */
        public function getFormId(){
            return 'generate_node';
        }

        /**
         * {@inheritdoc}
         */

        public function buildForm(array $form, FormStateInterface $form_state){
            $content = array(
                'article' => 'Article',
                'page' => 'Basic Page'
                
            );
            $form['type'] = array(
                '#type' => 'select',
                '#title' => t('Content Types'),
                '#options' => $content,
                '#required' => true
            );
            $form['element'] = [
                '#type' => 'textfield',
                '#attributes' => [
                    ' type' => 'number',
                ],
                '#title' => 'Enter number of Nodes to be generate',
                '#required' => true,
                '#maxlength' => 2
            ];
            $form['save'] = array(
                '#type' => 'submit',
                '#value' => 'Save',
                '#button_type' => 'primary'

            );

            return $form;

        }

         /**
         * {@inheritdoc}
         */
        public function validateform(array &$form, FormStateInterface $form_state){
            $nodes = $form_state->getValue('element');
            if($nodes < 2 || $nodes > 10){
                $form_state->setErrorByName('element',$this->t('Number of Nodes should be in between 2-10!'));
            }
        }
        
        public function submitForm(array &$form, FormStateInterface $form_state){
            for($i=0;$i<$form_state->getValue('element');$i++){
            $node = \Drupal::entityTypeManager()->getStorage('node')->create([
                'type' => $form_state->getValue('type'),
                'title' => 'New Node',
            ]);
            $node->save();
        }
            return drupal_set_message("New Node is created successfully");

        }
    }