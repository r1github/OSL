<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location: login.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    
<link rel="stylesheet" href="newquizz.css" class="href">
    <title>new quiz</title>
    

</head>

<body>
    <?php require "elements/nav.php" ?>
   
    <div class="nam">

    </div>
    <div class="head">
        <header>
            <div class="timer">
                <div class="time_text">Time Left</div>
                <div id="timer_sec">15</div>
            </div>

            <!-- <div id="showScore" class="scoreArea reload"> </div>-->
            <div class="s">
            <button id="submit">submit</button>
            <div id="show" class="scoreA"></div>
            </div>
           
        </header>
    </div>
    <h3 style="text-align:center; margin-top:-0.8rem;">Welcome  <?php echo $_SESSION['username'] ?></h3>
    <div class="main-div">
   
        <div class="inner-div">
        <div class = "divv" style="background-color: black;"><h4 style="color:white;">FACT OR FICTION: NINTENDO</h4>
        </div>
            <div class="h" style="margin-top:50px;">
                <h2 style="color:black;" class="questions">Questions come here</h2>
            </div>
        </div>

        <div class="inner-div2" style="margin-top:-8rem;">
            <ul>
                <li data-inline="true" style="float:left;">
                    <button name="answer" id="ans1" class="answer">submit</button>
                    <!-- <input type="button" name="answer" id="ans1" class="answer" value="True">
                    <label for="ans1" id="option1"></label> -->
                </li>

                <li data-inline="true" style="float:right" ;>
                    <button name="answer" id="ans2" class="answer">submit</button>
                    <!-- <input type="button" name="answer" id="ans2" class="answer" value="False">
                    <label for="ans2" id="option2"></label> -->
                </li>
            </ul>
        </div>

        
        

    </div>


        <!-- footer  -->
<div class="footer" style="margin-top:-2rem">
  <div class="foot">
  <img class="fb" src="pics/facebook.png" alt="facebook">
  <img class="fb" src="pics/twitter.png" alt="twitter">
  <img class="fb" src="pics/instagram.png" alt="insta">
  <p style="color:white;">@ xyz .com</p>
  </div>
</div>
    <script src="script.js"></script>
    <!-- <script src="questions.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>
</body>

</html>