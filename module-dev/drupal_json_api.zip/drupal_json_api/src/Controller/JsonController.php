<?php
/**
 * @file
 * Contains \Drupal\drupal_json_api\Controller\JsonController
 * check siteapikey, content-type and node id (/data/{key}/{type}/{nid})
 */
namespace Drupal\drupal_json_api\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\HeaderBag;
use Drupal\node\Entity\Node;
/**
 * Provides route responses for the Example module.
 */
class JsonController extends ControllerBase {
  public function get() { 
      $response = new JsonResponse();
      $config = \Drupal::config('system.site');
      $node = Node::load(random_int(1,10));
      $data = array(
          'site_name' =>$config->get('name'),
          'site_email' => $config->get('mail'),
          'random_node' => array(
              'title' => $node->get('title')->getValue()[0]['value'],
              'body' => $node->get('body')->getValue()[0]['value'],
          )
      );
      $response->setData($data);
      return $response;
  }

  public function data($key,$type,$nid) {
    $output = array(
      'status' => false,
      'data' => '',
    );
    $path = \Drupal::request()->getpathInfo();
    $arg  = explode('/',$path);
    $key = $arg[2];
    $type = $arg[3];
    $nid = $arg[4];
    $siteapikey = \Drupal::config('drupal_json_api.settings')->get('siteapikey');
    $conType = \Drupal::entityQuery('node')->sort('created', 'DESC')->execute();
    $node = \Drupal\node\Entity\Node::load($nid);
    if ( $key != $siteapikey || $type!=$conType || $nid!= $node) {
        //access denied
        $output['data'] = 'Access Denied';
        return new JsonResponse($output);
    }
    else {
      $serializer = \Drupal::service('serializer');
      //$node = Node::load(2);
      $data = $serializer->serialize($node, 'json', ['plugin_id' => 'entity']);
      $output['data'] = $data;
    }
    return new JsonResponse($output);
  }
}