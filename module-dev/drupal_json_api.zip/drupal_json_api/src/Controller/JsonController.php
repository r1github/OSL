<?php
namespace Drupal\drupal_json_api\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class JsonController
 * @package Drupal\drupal_json_api\Controller
 */
class JsonController {

  /**
   * @return JsonResponse
   */
  public function index() {
    return new JsonResponse([ 'data' => $this->getData()]);
  }

  /**
   * @return array
   */
  public function getData() {
    // $node = \Drupal\node\Entity\Node::load($nid);
    $result=[];
    $query = \Drupal::entityQuery('node')
    //   ->condition('type', 'article')
      ->sort('title', 'DESC');
    $nodes_ids = $query->execute();
    if ($nodes_ids) {
      foreach ($nodes_ids as $node_id) {
        $node = \Drupal\node\Entity\Node::load($node_id);
        $path = \Drupal::request()->getpathInfo();
        $arg  = explode('/',$path);
        $key = $arg[2];
        $type = $arg[3];
        $nid = $arg[4];
        $siteapikey = \Drupal::config('drupal_json_api.settings')->get('siteapikey');
        if($node_id == $nid && $key == $siteapikey ){
        $result[] = [
          "id" => $node->id(),
          "title" => $node->getTitle(),
          "body" => $node->body->value,
        //   "node"=>'article',
        ];
        } 
    }
    }
    return $result;
  }
  
}