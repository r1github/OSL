<?php
/**
 * @file
 * Contains \Drupal\drupal_json_api\Controller\SiteDataController
 */
namespace Drupal\drupal_json_api\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
/**
 * Provides route responses for the Example module.
 */
class SiteDataController extends ControllerBase {
  
  /**
   * @return JsonResponse
   */
  public function get() { 
    $response = new JsonResponse();
    $config = \Drupal::config('system.site');
    $node = Node::load(random_int(1,10));
    $data = array(
        'site_name' =>$config->get('name'),
        'site_email' => $config->get('mail'),
        'random_node' => array(
            'title' => $node->get('title')->getValue()[0]['value'],
            'body' => $node->get('body')->getValue()[0]['value'],
        )
    );
    $response->setData($data);
    return $response;
}
}