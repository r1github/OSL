<?php
    namespace Drupal\node_generator\Controller;
    use Drupal\Core\Controller\ControllerBase;

    class NodeGeneratorController extends ControllerBase{
        public function nodeGen(){
            return[];
        }
    }
?>