<?php
    /**
     * Contains \Drupal\node_json_data\Controller\UserController
     */
    namespace Drupal\node_json_data\Controller;
    use Drupal\Core\Controller\ControllerBase;
    use Symfony\Component\HttpFoundation\JsonResponse;

    class UserController {
        /**
         * @return JsonResponse
         */

         public function index() {
             return new JsonResponse(['data' => $this->getData(), 'method' => 'GET', ]);
         }

         /**
          * @return array
          */

          public function getData(){
              $result=[];
              $query = \Drupal::entityQuery('node')
                ->condition('type','article+page')
                ->sort('title','DESC');
              $nodes_ids = $query->execute();
              if($nodes_ids){
                  foreach($nodes_ids as $node_id){
                      $node = \Drupal\node\Entity\Node::load($node_id);
                      $result[] = [
                          "id" => $node->id(),
                          'title' => $node -> getTitle(),
                      ];
                  }
              }
              return $result;
          }
    
    } 