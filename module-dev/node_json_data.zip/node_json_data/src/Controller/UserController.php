<?php
     /**
     * Contains \Drupal\node_json_data\Controller\UserController
     */
    namespace Drupal\node_json_data\Controller;
    use Drupal\Core\Controller\ControllerBase;
    use Symfony\Component\HttpFoundation\JsonResponse;
    
    /**
     * Class UserController
     * @package Drupal\node_json_data\Controller
     */
    class UserController {
        /**
         * @return JsonResponse
         */
        public function index() {
            return new JsonResponse([ 'data' => $this->getData()]);
        }
    
      /**
       * @return array
       */

      public function getData() {
        $result=[];
        $query = \Drupal::entityQuery('node')
          ->sort('title', 'DESC');
        $nodes_ids = $query->execute();
        if ($nodes_ids) {
          foreach ($nodes_ids as $node_id) {
            $node = \Drupal\node\Entity\Node::load($node_id);
            $path = \Drupal::request()->getpathInfo();
            $arg  = explode('/',$path);
            $key = $arg[3];
            $nid = $arg[4];
            $apikey = \Drupal::config('node_json_data.settings')->get('apikey');
            if($node_id == $nid && $key == $apikey ){
            $result[] = [
              "id" => $node->id(),
              "title" => $node->getTitle(),
              "body" => $node->body->value,
            ];
            } 
        }
        }
        return $result;
      }
      
    }