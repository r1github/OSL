<?php
/**
 * @file
 * Contains \Drupal\node_json_data\Form\APISettingsForm
 */

namespace Drupal\node_json_data\Form;

use Drupal\Core\Form\ConfigFormBase;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Form\FormStateInterface;

/**
 * Defines a form to configure api key
 */

class APISettingsForm extends ConfigFormBase {
    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'api_admin_settings';
    }
    /**
     * {@inheritdoc}
     */
    protected function getEditableConfigNames() {
        return [
            'node_json_data.settings'
        ];
    } 
    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, Request $request = NULL){
        $types = node_type_get_names();
        $config = $this->config('node_json_data.settings');
        $form['apikey'] = [
            '#type' => 'textfield',
            '#title' => t('Enter 16 digit API KEY'),
            '#required' => true
        ];
        $form['array_filter'] = array('#type' =>'value', '#value' =>TRUE );
        return parent::buildForm($form,$form_state);
    }
     /**
         * {@inhertdoc}
         */
    public function validateform(array &$form, FormStateInterface $form_state){
        $api = $form_state->getValue('apikey');
        $x=strlen($api);
        // echo $x;
        if($x > 16){
            $form_state->setErrorByName('apikey',$this->t('Api Key length increased!'));
        }
        }
    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        //Retrieving the configuration
        // $result = array_filter($form_state->getValue('apikey'));
        // sort($result);
        // print_r($form_state->getValue('apikey'));
        // die();
        $this->config('node_json_data.settings')
            ->set('apikey', $form_state->getValue('apikey'))
            ->save();
            parent::submitForm($form, $form_state);
    }
} 