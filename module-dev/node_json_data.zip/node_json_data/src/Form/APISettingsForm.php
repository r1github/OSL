<?php
/**
 * @file
 * Contains \Drupal\node_json_data\Form\APISettingsForm
 */

namespace Drupal\node_json_data\Form;

use Drupal\Core\Form\ConfigFormBase;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Form\FormStateInterface;

/**
 * Defines a form to configure api key
 */

class APISettingsForm extends ConfigFormBase {
    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'api_admin_settings';
    }
    /**
     * {@inheritdoc}
     */
    protected function getEditableConfigNames() {
        return [
            'node_json_data.settings'
        ];
    } 
    public function buildForm(array $form, FormStateInterface $form_state, Request $request = NULL){
        $types = node_type_get_names();
        $config = $this->config('node_json_data.settings');
        $form['acceptkey'] = [
            '#type' => 'textfield',
            '#title' => t('Enter 16 digit API KEY'),
            '#default_value' => '',
            '#required' => true
        ];
        $form['array_filter'] = array('#type' =>'value', '#value' =>TRUE );
        return parent::buildForm($form,$form_state);
    }
    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $result = array_filter($form_state->getValue('acceptkey'));
        sort($result);
        $this->config('node_json_data.settings')
            ->set('result', $result)
            ->save();
            parent::submitForm($form, $form_state);
    }
} 