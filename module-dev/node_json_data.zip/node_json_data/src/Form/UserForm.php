<?php
/**
 * @file
 * Contains \Drupal\node_json_data\Form\UserForm
 */
    namespace Drupal\node_json_data\Form;
    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;

    class UserForm extends FormBase{
        /**
         * {@inheritdoc}
         */

         public function getFormId(){
             return 'create_user';
         }

         /**
         * {@inheritdoc}
         */
        public function buildForm(array $form, FormStateInterface $form_state){
            $form['name'] = array(
                '#type' => 'textfield',
                '#title' => t('Name'),
                '#default_value' => '',
                '#required' => true
            );
            $form['apikey'] = array(
                '#type' => 'textfield',
                '#title' => t('Enter 16 digit API Key'),
                '#default_value' => '',
                '#required' => true
            );
            $form['save'] = array(
                '#type' => 'submit',
                '#value' => 'Save API Key',
                '#button_type' => 'primary'

            );

            return $form;

        }

        /**
         * {@inhertdoc}
         */
        public function validateform(array &$form, FormStateInterface $form_state){
            $api = $form_state->getValue('apikey');
            $x=strlen($api);
            echo $x;
            if($x > 16){
                $form_state->setErrorByName('api',$this->t('Api Key length increased!'));
            }
        }



        /**
         * {@inhertdoc}
         */

        public function submitForm(array &$form, FormStateInterface $form_state){
            $key = $form_state['apikey'];
            // $postData = $form_state->getValues();
            // echo "<pre>";
            // print_r($postData);
            // echo "</pre>";
            // exit;

        }
         
    }
